/**
 * Navbar Component
 * Navigation tabs for the main sections of the app.
 */

import { NavLink } from 'react-router-dom';
import { useHealthCheck } from '../hooks/useStatus';

export default function Navbar() {
    const { data: health, isError } = useHealthCheck();

    const isConnected = health?.status === 'ok';

    return (
        <nav className="border-b border-[var(--color-border)] bg-white sticky top-0 z-50">
            <div className="container">
                <div className="flex items-center justify-between h-16">
                    {/* Logo */}
                    <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-black rounded flex items-center justify-center">
                            <span className="text-white font-bold text-sm">IP</span>
                        </div>
                        <span className="font-semibold text-lg tracking-tight">Image Processor</span>
                    </div>

                    {/* Navigation Links */}
                    <div className="flex items-center gap-1">
                        <NavLink
                            to="/"
                            className={({ isActive }) =>
                                `px-4 py-2 text-sm font-medium rounded transition-colors ${isActive
                                    ? 'bg-black text-white'
                                    : 'text-[var(--color-text-secondary)] hover:text-black hover:bg-[var(--color-bg-secondary)]'
                                }`
                            }
                        >
                            Dashboard
                        </NavLink>
                        <NavLink
                            to="/history"
                            className={({ isActive }) =>
                                `px-4 py-2 text-sm font-medium rounded transition-colors ${isActive
                                    ? 'bg-black text-white'
                                    : 'text-[var(--color-text-secondary)] hover:text-black hover:bg-[var(--color-bg-secondary)]'
                                }`
                            }
                        >
                            History
                        </NavLink>
                        <NavLink
                            to="/system"
                            className={({ isActive }) =>
                                `px-4 py-2 text-sm font-medium rounded transition-colors ${isActive
                                    ? 'bg-black text-white'
                                    : 'text-[var(--color-text-secondary)] hover:text-black hover:bg-[var(--color-bg-secondary)]'
                                }`
                            }
                        >
                            System
                        </NavLink>
                    </div>

                    {/* Connection Status */}
                    <div className="flex items-center gap-2">
                        <span
                            className={`status-dot ${isConnected ? 'success' : isError ? 'error' : 'warning'}`}
                        />
                        <span className="text-sm text-[var(--color-text-secondary)]">
                            {isConnected ? 'Connected' : isError ? 'Disconnected' : 'Connecting...'}
                        </span>
                    </div>
                </div>
            </div>
        </nav>
    );
}
