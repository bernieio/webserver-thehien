/**
 * Layout Component
 * Main layout wrapper with navigation and content area.
 */

import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';

export default function Layout() {
    return (
        <div className="min-h-screen bg-white">
            <Navbar />
            <main className="container py-6">
                <Outlet />
            </main>
        </div>
    );
}
