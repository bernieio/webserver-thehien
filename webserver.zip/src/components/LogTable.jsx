/**
 * LogTable Component
 * Tabular display of logs with filtering, pagination, and CSV export.
 */

import { useState } from 'react';
import { useLogs } from '../hooks/useLogs';
import { formatDateTime } from '../utils/formatters';

export default function LogTable({ startDate, endDate, logType, logLevel }) {
    const [page, setPage] = useState(1);
    const pageSize = 25;

    const { data, isLoading, isError } = useLogs({
        start_date: startDate,
        end_date: endDate,
        log_type: logType,
        level: logLevel,
        page,
        page_size: pageSize,
    });

    const getLevelBadge = (level) => {
        switch (level?.toLowerCase()) {
            case 'debug': return 'badge';
            case 'info': return 'badge badge-info';
            case 'warning': return 'badge badge-warning';
            case 'error': return 'badge badge-error';
            case 'critical': return 'badge badge-error';
            default: return 'badge';
        }
    };

    const getTypeBadge = (type) => {
        switch (type?.toLowerCase()) {
            case 'activity': return 'badge badge-success';
            case 'server': return 'badge badge-info';
            case 'error': return 'badge badge-error';
            default: return 'badge';
        }
    };

    const handleExportCSV = () => {
        const logs = data?.items ?? [];
        if (logs.length === 0) return;

        // CSV header
        const headers = ['Timestamp', 'Type', 'Level', 'Message', 'Source'];

        // CSV rows
        const rows = logs.map(log => [
            formatDateTime(log.created_at),
            log.type || '',
            log.level || '',
            `"${(log.message || '').replace(/"/g, '""')}"`, // Escape quotes in message
            log.source || '',
        ]);

        // Build CSV content
        const csvContent = [
            headers.join(','),
            ...rows.map(row => row.join(','))
        ].join('\n');

        // Download
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `logs_${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    };

    if (isLoading) {
        return (
            <div className="card animate-pulse">
                <div className="space-y-3">
                    {[1, 2, 3, 4, 5].map((i) => (
                        <div key={i} className="h-8 bg-[var(--color-bg-tertiary)] rounded" />
                    ))}
                </div>
            </div>
        );
    }

    if (isError) {
        return (
            <div className="card border-[var(--color-error)] text-center py-8">
                <p className="text-[var(--color-error)]">Failed to load logs</p>
            </div>
        );
    }

    const logs = data?.items ?? [];
    const total = data?.total ?? 0;
    const hasMore = data?.has_more ?? false;

    if (logs.length === 0) {
        return (
            <div className="empty-state py-12">
                <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <p className="mt-2">No logs found</p>
                <p className="text-sm">Try adjusting your filters or wait for new log entries.</p>
            </div>
        );
    }

    return (
        <div>
            {/* Header with Export button */}
            <div className="flex items-center justify-between mb-4">
                <div className="text-sm text-[var(--color-text-secondary)]">
                    {total} log entries
                </div>
                <button
                    onClick={handleExportCSV}
                    className="btn btn-secondary flex items-center gap-2"
                >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                    Export CSV
                </button>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
                <table className="table">
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>Type</th>
                            <th>Level</th>
                            <th>Message</th>
                            <th>Source</th>
                        </tr>
                    </thead>
                    <tbody>
                        {logs.map((log) => (
                            <tr key={log.id}>
                                <td className="text-sm text-[var(--color-text-secondary)] whitespace-nowrap">
                                    {formatDateTime(log.created_at)}
                                </td>
                                <td>
                                    <span className={getTypeBadge(log.type)}>{log.type}</span>
                                </td>
                                <td>
                                    <span className={getLevelBadge(log.level)}>{log.level}</span>
                                </td>
                                <td className="max-w-md truncate" title={log.message}>
                                    {log.message}
                                </td>
                                <td className="text-sm text-[var(--color-text-muted)]">
                                    {log.source || '-'}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-[var(--color-border-light)]">
                <div className="text-sm text-[var(--color-text-secondary)]">
                    Showing {(page - 1) * pageSize + 1} - {Math.min(page * pageSize, total)} of {total}
                </div>
                <div className="flex gap-2">
                    <button
                        onClick={() => setPage((p) => Math.max(1, p - 1))}
                        disabled={page === 1}
                        className="btn btn-secondary"
                    >
                        Previous
                    </button>
                    <button
                        onClick={() => setPage((p) => p + 1)}
                        disabled={!hasMore}
                        className="btn btn-secondary"
                    >
                        Next
                    </button>
                </div>
            </div>
        </div>
    );
}
