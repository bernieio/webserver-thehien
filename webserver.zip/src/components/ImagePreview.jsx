/**
 * ImagePreview Component
 * Auto-processes queue and displays images with history scroller.
 */

import { useState, useEffect, useRef } from 'react';
import { usePopFromQueue } from '../hooks/useImages';
import { useStatus } from '../hooks/useStatus';
import { formatFileSize, formatDimensions, formatRelativeTime } from '../utils/formatters';

export default function ImagePreview() {
    const { data: status } = useStatus({ refetchInterval: 500 });
    const popMutation = usePopFromQueue();

    const [currentImage, setCurrentImage] = useState(null);
    const [imageHistory, setImageHistory] = useState([]);
    const [isProcessing, setIsProcessing] = useState(false);
    const historyRef = useRef(null);

    const queueSize = status?.queue?.current_size ?? 0;

    // Auto-pop from queue when items are available
    useEffect(() => {
        const processQueue = async () => {
            if (queueSize > 0 && !isProcessing && !popMutation.isPending) {
                setIsProcessing(true);
                try {
                    const result = await popMutation.mutateAsync();
                    if (result.success && result.image) {
                        // Update current image
                        setCurrentImage(result.image);

                        // Add to history (newest first)
                        setImageHistory(prev => {
                            const newHistory = [result.image, ...prev];
                            // Keep max 50 items in history
                            return newHistory.slice(0, 50);
                        });
                    }
                } catch (error) {
                    console.error('Auto-pop failed:', error);
                } finally {
                    setIsProcessing(false);
                }
            }
        };

        processQueue();
    }, [queueSize, isProcessing, popMutation.isPending]);

    // Auto-scroll history to top when new image added
    useEffect(() => {
        if (historyRef.current) {
            historyRef.current.scrollTop = 0;
        }
    }, [imageHistory.length]);

    const displayImage = currentImage || status?.last_image;

    return (
        <div className="card">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-[var(--color-text-secondary)] uppercase tracking-wider">
                    Auto-Processing Queue
                </h3>
                <div className="flex items-center gap-3">
                    {/* Processing indicator */}
                    {(isProcessing || popMutation.isPending) && (
                        <div className="flex items-center gap-2 text-sm text-[var(--color-info)]">
                            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                            </svg>
                            Processing...
                        </div>
                    )}

                    {/* Queue size badge */}
                    <span className={`badge ${queueSize > 0 ? 'badge-info' : ''}`}>
                        Queue: {queueSize}
                    </span>

                    {/* History count */}
                    <span className="badge">
                        History: {imageHistory.length}
                    </span>
                </div>
            </div>

            {/* Main content with image preview and history scroller */}
            <div className="flex gap-4">
                {/* Main image display */}
                <div className="flex-1">
                    {displayImage ? (
                        <div className="space-y-4">
                            {/* Image Preview */}
                            <div className="relative aspect-video bg-[var(--color-bg-secondary)] rounded-lg overflow-hidden">
                                <img
                                    src={displayImage.url}
                                    alt={displayImage.filename}
                                    className="w-full h-full object-contain"
                                    onError={(e) => {
                                        e.target.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23999" stroke-width="1"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>';
                                    }}
                                />

                                {/* Live indicator */}
                                {(isProcessing || popMutation.isPending) && (
                                    <div className="absolute top-3 right-3 flex items-center gap-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                                        <span className="status-dot animate-pulse" style={{ background: '#22c55e' }} />
                                        LIVE
                                    </div>
                                )}
                            </div>

                            {/* Image Info */}
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                                <div>
                                    <div className="text-[var(--color-text-muted)]">Filename</div>
                                    <div className="font-medium truncate" title={displayImage.filename}>
                                        {displayImage.filename}
                                    </div>
                                </div>
                                <div>
                                    <div className="text-[var(--color-text-muted)]">Dimensions</div>
                                    <div className="font-medium">
                                        {formatDimensions(displayImage.width, displayImage.height) || 'N/A'}
                                    </div>
                                </div>
                                <div>
                                    <div className="text-[var(--color-text-muted)]">Size</div>
                                    <div className="font-medium">
                                        {formatFileSize(displayImage.size_bytes) || 'N/A'}
                                    </div>
                                </div>
                                <div>
                                    <div className="text-[var(--color-text-muted)]">Processed</div>
                                    <div className="font-medium">
                                        {formatRelativeTime(displayImage.timestamp || displayImage.created_at)}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="empty-state py-12">
                            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                            <p className="mt-2">Waiting for images...</p>
                            <p className="text-sm">
                                Load images from the desktop GUI to auto-process.
                            </p>
                        </div>
                    )}
                </div>

                {/* Image History Scroller (Right side) */}
                <div className="w-48 flex-shrink-0">
                    <div className="text-xs font-medium text-[var(--color-text-secondary)] uppercase tracking-wider mb-2">
                        Recent Images
                    </div>
                    <div
                        ref={historyRef}
                        className="overflow-y-auto bg-[var(--color-bg-secondary)] rounded-lg"
                        style={{ height: '400px' }}
                    >
                        {imageHistory.length > 0 ? (
                            <div className="p-2 space-y-2">
                                {imageHistory.map((img, index) => (
                                    <div
                                        key={img.id || index}
                                        className={`cursor-pointer rounded overflow-hidden border-2 transition-all ${currentImage?.id === img.id
                                                ? 'border-black'
                                                : 'border-transparent hover:border-[var(--color-border)]'
                                            }`}
                                        onClick={() => setCurrentImage(img)}
                                    >
                                        <div className="aspect-video bg-[var(--color-bg-tertiary)] relative">
                                            <img
                                                src={img.url}
                                                alt={img.filename}
                                                className="w-full h-full object-cover"
                                                loading="lazy"
                                                onError={(e) => {
                                                    e.target.style.display = 'none';
                                                }}
                                            />
                                            {index === 0 && (
                                                <div className="absolute top-1 left-1 bg-[var(--color-success)] text-white text-[10px] px-1 rounded">
                                                    NEW
                                                </div>
                                            )}
                                        </div>
                                        <div className="p-1.5 bg-white">
                                            <div className="text-[10px] font-medium truncate">
                                                {img.filename}
                                            </div>
                                            <div className="text-[9px] text-[var(--color-text-muted)]">
                                                {formatDimensions(img.width, img.height)}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="flex items-center justify-center h-full text-[var(--color-text-muted)] text-xs">
                                No images yet
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Error Display */}
            {popMutation.isError && (
                <div className="mt-4 p-3 bg-[#fee2e2] text-[#991b1b] rounded text-sm">
                    Error: {popMutation.error?.message || 'Failed to process image'}
                </div>
            )}
        </div>
    );
}
