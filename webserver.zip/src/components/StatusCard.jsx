/**
 * StatusCard Component
 * Displays queue status and server information.
 */

import { useStatus } from '../hooks/useStatus';
import { formatRelativeTime } from '../utils/formatters';

export default function StatusCard() {
    const { data, isLoading, isError } = useStatus();

    if (isLoading) {
        return (
            <div className="card animate-pulse">
                <div className="h-4 bg-[var(--color-bg-tertiary)] rounded w-1/3 mb-4"></div>
                <div className="h-8 bg-[var(--color-bg-tertiary)] rounded w-1/2"></div>
            </div>
        );
    }

    if (isError) {
        return (
            <div className="card border-[var(--color-error)]">
                <div className="flex items-center gap-2 text-[var(--color-error)]">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span className="font-medium">Connection Error</span>
                </div>
                <p className="text-sm text-[var(--color-text-secondary)] mt-2">
                    Unable to connect to the backend server.
                </p>
            </div>
        );
    }

    const queue = data?.queue || {};
    const system = data?.system || {};

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Queue Status */}
            <div className="card">
                <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-medium text-[var(--color-text-secondary)] uppercase tracking-wider">
                        Queue
                    </h3>
                    <span className={`badge ${queue.current_size > 0 ? 'badge-info' : ''}`}>
                        {queue.is_full ? 'Full' : queue.is_empty ? 'Empty' : 'Active'}
                    </span>
                </div>
                <div className="text-4xl font-bold mb-1">
                    {queue.current_size ?? 0}
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">
                    of {queue.max_size ?? 100} capacity
                </div>
                <div className="mt-4 pt-4 border-t border-[var(--color-border-light)] grid grid-cols-2 gap-4 text-sm">
                    <div>
                        <div className="text-[var(--color-text-muted)]">Pushed</div>
                        <div className="font-medium">{queue.total_pushed ?? 0}</div>
                    </div>
                    <div>
                        <div className="text-[var(--color-text-muted)]">Popped</div>
                        <div className="font-medium">{queue.total_popped ?? 0}</div>
                    </div>
                </div>
            </div>

            {/* System Status */}
            <div className="card">
                <h3 className="text-sm font-medium text-[var(--color-text-secondary)] uppercase tracking-wider mb-2">
                    System
                </h3>
                <div className="space-y-3">
                    <div className="flex justify-between items-center">
                        <span className="text-[var(--color-text-secondary)]">Memory</span>
                        <span className="font-medium">{system.memory_mb ?? 0} MB</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-[var(--color-text-secondary)]">CPU</span>
                        <span className="font-medium">{system.cpu_percent ?? 0}%</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-[var(--color-text-secondary)]">Threads</span>
                        <span className="font-medium">{system.threads ?? 0}</span>
                    </div>
                </div>
            </div>

            {/* Uptime */}
            <div className="card">
                <h3 className="text-sm font-medium text-[var(--color-text-secondary)] uppercase tracking-wider mb-2">
                    Server Uptime
                </h3>
                <div className="text-4xl font-bold mb-1">
                    {Math.floor((data?.uptime_seconds ?? 0) / 60)}
                    <span className="text-lg font-normal text-[var(--color-text-secondary)]">min</span>
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">
                    Last push: {formatRelativeTime(queue.last_push_time)}
                </div>
                <div className="text-sm text-[var(--color-text-secondary)]">
                    Last pop: {formatRelativeTime(queue.last_pop_time)}
                </div>
            </div>
        </div>
    );
}
