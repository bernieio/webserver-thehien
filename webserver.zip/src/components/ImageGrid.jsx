/**
 * ImageGrid Component
 * Advanced grid display with multi-select, group selection, ZIP download, and lightbox.
 */

import { useState, useMemo } from 'react';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { useImages, useDeleteImage } from '../hooks/useImages';
import { formatFileSize, formatDimensions, formatDateTime } from '../utils/formatters';
import ImageLightbox from './ImageLightbox';

export default function ImageGrid({ startDate, endDate }) {
    const [page, setPage] = useState(1);
    const [selectedIds, setSelectedIds] = useState(new Set());
    const [selectAll, setSelectAll] = useState(false);
    const [lightboxIndex, setLightboxIndex] = useState(null);
    const [isDownloading, setIsDownloading] = useState(false);
    const pageSize = 50;

    const { data, isLoading, isError } = useImages({
        start_date: startDate,
        end_date: endDate,
        page,
        page_size: pageSize,
    });

    const deleteMutation = useDeleteImage();

    const images = data?.items ?? [];
    const total = data?.total ?? 0;
    const hasMore = data?.has_more ?? false;

    // Group images by date
    const groupedImages = useMemo(() => {
        const groups = {};
        images.forEach((img) => {
            const date = new Date(img.created_at);
            const year = date.getFullYear();
            const month = date.toLocaleString('default', { month: 'long', year: 'numeric' });
            const day = date.toLocaleDateString();

            if (!groups[year]) groups[year] = {};
            if (!groups[year][month]) groups[year][month] = {};
            if (!groups[year][month][day]) groups[year][month][day] = [];
            groups[year][month][day].push(img);
        });
        return groups;
    }, [images]);

    const allSelected = images.length > 0 && (selectAll || images.every(img => selectedIds.has(img.id)));

    const toggleSelect = (id) => {
        setSelectAll(false);
        setSelectedIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(id)) {
                newSet.delete(id);
            } else {
                newSet.add(id);
            }
            return newSet;
        });
    };

    const toggleSelectAll = () => {
        if (allSelected) {
            setSelectedIds(new Set());
            setSelectAll(false);
        } else {
            setSelectAll(true);
            setSelectedIds(new Set(images.map(img => img.id)));
        }
    };

    const toggleDaySelect = (dayImages) => {
        const dayIds = dayImages.map(img => img.id);
        const allDaySelected = dayIds.every(id => selectedIds.has(id));

        setSelectAll(false);
        setSelectedIds(prev => {
            const newSet = new Set(prev);
            if (allDaySelected) {
                dayIds.forEach(id => newSet.delete(id));
            } else {
                dayIds.forEach(id => newSet.add(id));
            }
            return newSet;
        });
    };

    const toggleMonthSelect = (monthData) => {
        const monthImages = Object.values(monthData).flat();
        const monthIds = monthImages.map(img => img.id);
        const allMonthSelected = monthIds.every(id => selectedIds.has(id));

        setSelectAll(false);
        setSelectedIds(prev => {
            const newSet = new Set(prev);
            if (allMonthSelected) {
                monthIds.forEach(id => newSet.delete(id));
            } else {
                monthIds.forEach(id => newSet.add(id));
            }
            return newSet;
        });
    };

    const toggleYearSelect = (yearData) => {
        const yearImages = Object.values(yearData).flatMap(month => Object.values(month).flat());
        const yearIds = yearImages.map(img => img.id);
        const allYearSelected = yearIds.every(id => selectedIds.has(id));

        setSelectAll(false);
        setSelectedIds(prev => {
            const newSet = new Set(prev);
            if (allYearSelected) {
                yearIds.forEach(id => newSet.delete(id));
            } else {
                yearIds.forEach(id => newSet.add(id));
            }
            return newSet;
        });
    };

    // Download selected images as ZIP via backend proxy
    const handleDownloadAll = async () => {
        const selectedImages = images.filter(img => selectedIds.has(img.id) || selectAll);
        if (selectedImages.length === 0) return;

        setIsDownloading(true);
        try {
            const zip = new JSZip();

            // Fetch images through backend proxy (avoids CORS)
            const results = await Promise.allSettled(
                selectedImages.map(async (img, index) => {
                    const response = await fetch(`/api/images/${img.id}/download`);
                    if (!response.ok) throw new Error(`HTTP ${response.status}`);
                    const blob = await response.blob();
                    const filename = selectedImages.length > 1 ? `${index + 1}_${img.filename}` : img.filename;
                    zip.file(filename, blob);
                    return img.filename;
                })
            );

            const succeeded = results.filter(r => r.status === 'fulfilled').length;
            const failed = results.filter(r => r.status === 'rejected').length;

            if (succeeded === 0) throw new Error('All downloads failed');

            const content = await zip.generateAsync({ type: 'blob' });
            const dateStr = new Date().toISOString().split('T')[0];
            saveAs(content, `images_${dateStr}_${succeeded}files.zip`);

            if (failed > 0) alert(`Downloaded ${succeeded} images. ${failed} failed.`);

            setSelectedIds(new Set());
            setSelectAll(false);
        } catch (error) {
            console.error('ZIP creation failed:', error);
            alert('Failed to create ZIP: ' + error.message);
        } finally {
            setIsDownloading(false);
        }
    };

    const clearSelection = () => {
        setSelectedIds(new Set());
        setSelectAll(false);
    };

    const openLightbox = (index) => setLightboxIndex(index);
    const getImageIndex = (imageId) => images.findIndex(img => img.id === imageId);

    const selectedCount = selectAll ? total : selectedIds.size;

    if (isLoading) {
        return (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((i) => (
                    <div key={i} className="animate-pulse">
                        <div className="aspect-square bg-[var(--color-bg-tertiary)] rounded-lg" />
                    </div>
                ))}
            </div>
        );
    }

    if (isError) {
        return (
            <div className="card border-[var(--color-error)] text-center py-8">
                <p className="text-[var(--color-error)]">Failed to load images</p>
            </div>
        );
    }

    if (images.length === 0) {
        return (
            <div className="empty-state py-12">
                <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p className="mt-2">No images found</p>
                <p className="text-sm">Try adjusting your date filters or process some images first.</p>
            </div>
        );
    }

    return (
        <div>
            {/* Header with selection controls */}
            <div className="flex items-center justify-between mb-4 sticky top-0 bg-white py-2 z-10 border-b border-[var(--color-border-light)]">
                <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                        <input
                            type="checkbox"
                            checked={allSelected}
                            onChange={toggleSelectAll}
                            className="w-5 h-5 rounded border-2 border-[var(--color-border)] checked:bg-black checked:border-black cursor-pointer"
                        />
                        <span className="text-sm font-medium">Select All</span>
                    </label>
                    <span className="text-sm text-[var(--color-text-secondary)]">{total} images total</span>
                </div>

                <div className="flex items-center gap-3">
                    {selectedCount > 0 && (
                        <>
                            <span className="text-sm text-[var(--color-text-secondary)]">{selectedCount} selected</span>
                            <button onClick={clearSelection} className="text-sm text-[var(--color-text-secondary)] hover:text-black underline">Clear</button>
                        </>
                    )}
                    {selectedCount > 0 && (
                        <button onClick={handleDownloadAll} disabled={isDownloading} className="btn btn-primary flex items-center gap-2">
                            {isDownloading ? (
                                <>
                                    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                                    </svg>
                                    Creating ZIP...
                                </>
                            ) : (
                                <>
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                                    </svg>
                                    Download ({selectedCount})
                                </>
                            )}
                        </button>
                    )}
                </div>
            </div>

            {/* Grouped Images */}
            <div className="space-y-6">
                {Object.entries(groupedImages).sort((a, b) => b[0] - a[0]).map(([year, months]) => (
                    <div key={year} className="space-y-4">
                        <div className="flex items-center gap-2 border-b-2 border-black pb-2">
                            <input
                                type="checkbox"
                                checked={Object.values(months).flatMap(m => Object.values(m).flat()).every(img => selectedIds.has(img.id))}
                                onChange={() => toggleYearSelect(months)}
                                className="w-5 h-5 rounded border-2 border-[var(--color-border)] checked:bg-black checked:border-black cursor-pointer"
                            />
                            <h2 className="text-xl font-bold">{year}</h2>
                            <span className="text-sm text-[var(--color-text-secondary)]">({Object.values(months).flatMap(m => Object.values(m).flat()).length} images)</span>
                        </div>

                        {Object.entries(months).sort((a, b) => new Date(b[0]) - new Date(a[0])).map(([month, days]) => (
                            <div key={month} className="space-y-3 pl-4">
                                <div className="flex items-center gap-2">
                                    <input
                                        type="checkbox"
                                        checked={Object.values(days).flat().every(img => selectedIds.has(img.id))}
                                        onChange={() => toggleMonthSelect(days)}
                                        className="w-4 h-4 rounded border-2 border-[var(--color-border)] checked:bg-black checked:border-black cursor-pointer"
                                    />
                                    <h3 className="text-lg font-semibold text-[var(--color-text-secondary)]">{month}</h3>
                                    <span className="text-xs text-[var(--color-text-muted)]">({Object.values(days).flat().length})</span>
                                </div>

                                {Object.entries(days).sort((a, b) => new Date(b[0]) - new Date(a[0])).map(([day, dayImages]) => (
                                    <div key={day} className="pl-4">
                                        <div className="flex items-center gap-2 mb-2">
                                            <input
                                                type="checkbox"
                                                checked={dayImages.every(img => selectedIds.has(img.id))}
                                                onChange={() => toggleDaySelect(dayImages)}
                                                className="w-4 h-4 rounded border-2 border-[var(--color-border)] checked:bg-black checked:border-black cursor-pointer"
                                            />
                                            <span className="text-sm font-medium">{day}</span>
                                            <span className="text-xs text-[var(--color-text-muted)]">({dayImages.length} images)</span>
                                        </div>

                                        <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-8 gap-2">
                                            {dayImages.map((image) => {
                                                const isSelected = selectedIds.has(image.id);
                                                const flatIndex = getImageIndex(image.id);

                                                return (
                                                    <div
                                                        key={image.id}
                                                        className={`relative group cursor-pointer rounded-lg overflow-hidden border-2 transition-all ${isSelected ? 'border-black ring-2 ring-black/20' : 'border-transparent hover:border-[var(--color-border)]'}`}
                                                    >
                                                        <div
                                                            className={`absolute top-1 left-1 z-10 ${isSelected || 'opacity-0 group-hover:opacity-100'} transition-opacity`}
                                                            onClick={(e) => { e.stopPropagation(); toggleSelect(image.id); }}
                                                        >
                                                            <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${isSelected ? 'bg-black border-black text-white' : 'bg-white/90 border-white shadow'}`}>
                                                                {isSelected && (
                                                                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                                                                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                                                    </svg>
                                                                )}
                                                            </div>
                                                        </div>

                                                        <div className="aspect-square bg-[var(--color-bg-secondary)]" onClick={() => openLightbox(flatIndex)}>
                                                            <img
                                                                src={image.url}
                                                                alt={image.filename}
                                                                className="w-full h-full object-cover"
                                                                loading="lazy"
                                                                onError={(e) => {
                                                                    e.target.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23999" stroke-width="1"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>';
                                                                }}
                                                            />
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ))}
                    </div>
                ))}
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between mt-6 pt-4 border-t border-[var(--color-border-light)]">
                <div className="text-sm text-[var(--color-text-secondary)]">
                    Showing {(page - 1) * pageSize + 1} - {Math.min(page * pageSize, total)} of {total}
                </div>
                <div className="flex gap-2">
                    <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page === 1} className="btn btn-secondary">Previous</button>
                    <button onClick={() => setPage((p) => p + 1)} disabled={!hasMore} className="btn btn-secondary">Next</button>
                </div>
            </div>

            {/* Lightbox */}
            {lightboxIndex !== null && (
                <ImageLightbox
                    image={images[lightboxIndex]}
                    onClose={() => setLightboxIndex(null)}
                    onPrev={() => setLightboxIndex(i => Math.max(0, i - 1))}
                    onNext={() => setLightboxIndex(i => Math.min(images.length - 1, i + 1))}
                    hasPrev={lightboxIndex > 0}
                    hasNext={lightboxIndex < images.length - 1}
                />
            )}
        </div>
    );
}
