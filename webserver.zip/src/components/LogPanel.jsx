/**
 * LogPanel Component
 * Real-time log display panel with auto-scroll.
 */

import { useRef, useEffect } from 'react';
import { useLatestLogs } from '../hooks/useLogs';
import { formatLogTime } from '../utils/formatters';

export default function LogPanel({ type = 'activity', title = 'Activity Logs', maxHeight = '300px' }) {
    const { data, isLoading } = useLatestLogs();
    const scrollRef = useRef(null);

    // Get logs based on type
    const logs = type === 'activity' ? data?.activity : data?.server;

    // Auto-scroll to bottom when new logs arrive
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [logs]);

    const getLevelClass = (level) => {
        switch (level?.toLowerCase()) {
            case 'debug': return 'log-debug';
            case 'info': return 'log-info';
            case 'warning': return 'log-warning';
            case 'error': return 'log-error';
            case 'critical': return 'log-critical';
            default: return '';
        }
    };

    const getLevelBadge = (level) => {
        switch (level?.toLowerCase()) {
            case 'debug': return 'badge';
            case 'info': return 'badge badge-info';
            case 'warning': return 'badge badge-warning';
            case 'error': return 'badge badge-error';
            case 'critical': return 'badge badge-error';
            default: return 'badge';
        }
    };

    return (
        <div className="card">
            <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-medium text-[var(--color-text-secondary)] uppercase tracking-wider">
                    {title}
                </h3>
                <span className="text-xs text-[var(--color-text-muted)]">
                    {logs?.length ?? 0} entries
                </span>
            </div>

            <div
                ref={scrollRef}
                className="overflow-y-auto font-mono text-xs bg-[var(--color-bg-secondary)] rounded-lg p-3"
                style={{ maxHeight }}
            >
                {isLoading ? (
                    <div className="animate-pulse space-y-2">
                        {[1, 2, 3].map((i) => (
                            <div key={i} className="h-4 bg-[var(--color-bg-tertiary)] rounded w-full" />
                        ))}
                    </div>
                ) : logs && logs.length > 0 ? (
                    <div className="space-y-1">
                        {logs.map((log, index) => (
                            <div key={index} className="flex items-start gap-2 py-1 border-b border-[var(--color-border-light)] last:border-0">
                                <span className="text-[var(--color-text-muted)] flex-shrink-0">
                                    {formatLogTime(log.timestamp || log.created_at)}
                                </span>
                                {log.level && (
                                    <span className={`${getLevelBadge(log.level)} flex-shrink-0`}>
                                        {log.level.toUpperCase()}
                                    </span>
                                )}
                                <span className={`${getLevelClass(log.level)} break-all`}>
                                    {log.message || log.action || JSON.stringify(log)}
                                </span>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center text-[var(--color-text-muted)] py-4">
                        No logs yet
                    </div>
                )}
            </div>
        </div>
    );
}
