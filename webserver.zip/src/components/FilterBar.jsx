/**
 * FilterBar Component
 * Date and type filters for history views.
 */

import { getToday, getDaysAgo } from '../utils/formatters';

export default function FilterBar({
    startDate,
    endDate,
    logType,
    logLevel,
    onStartDateChange,
    onEndDateChange,
    onLogTypeChange,
    onLogLevelChange,
    showLogFilters = false,
}) {
    const presets = [
        { label: 'Today', start: getToday(), end: getToday() },
        { label: '7 Days', start: getDaysAgo(7), end: getToday() },
        { label: '30 Days', start: getDaysAgo(30), end: getToday() },
        { label: '90 Days', start: getDaysAgo(90), end: getToday() },
    ];

    const applyPreset = (preset) => {
        onStartDateChange(preset.start);
        onEndDateChange(preset.end);
    };

    const clearFilters = () => {
        onStartDateChange('');
        onEndDateChange('');
        if (onLogTypeChange) onLogTypeChange('');
        if (onLogLevelChange) onLogLevelChange('');
    };

    return (
        <div className="card mb-6">
            <div className="flex flex-wrap items-center gap-4">
                {/* Date Range */}
                <div className="flex items-center gap-2">
                    <label className="text-sm text-[var(--color-text-secondary)]">From:</label>
                    <input
                        type="date"
                        value={startDate || ''}
                        onChange={(e) => onStartDateChange(e.target.value)}
                        className="text-sm"
                    />
                </div>

                <div className="flex items-center gap-2">
                    <label className="text-sm text-[var(--color-text-secondary)]">To:</label>
                    <input
                        type="date"
                        value={endDate || ''}
                        onChange={(e) => onEndDateChange(e.target.value)}
                        className="text-sm"
                    />
                </div>

                {/* Quick Presets */}
                <div className="flex gap-1">
                    {presets.map((preset) => (
                        <button
                            key={preset.label}
                            onClick={() => applyPreset(preset)}
                            className={`px-3 py-1 text-xs rounded border transition-colors ${startDate === preset.start && endDate === preset.end
                                    ? 'bg-black text-white border-black'
                                    : 'border-[var(--color-border)] hover:border-black'
                                }`}
                        >
                            {preset.label}
                        </button>
                    ))}
                </div>

                {/* Log Type Filter */}
                {showLogFilters && onLogTypeChange && (
                    <div className="flex items-center gap-2">
                        <label className="text-sm text-[var(--color-text-secondary)]">Type:</label>
                        <select
                            value={logType || ''}
                            onChange={(e) => onLogTypeChange(e.target.value)}
                            className="text-sm"
                        >
                            <option value="">All Types</option>
                            <option value="activity">Activity</option>
                            <option value="server">Server</option>
                            <option value="error">Error</option>
                        </select>
                    </div>
                )}

                {/* Log Level Filter */}
                {showLogFilters && onLogLevelChange && (
                    <div className="flex items-center gap-2">
                        <label className="text-sm text-[var(--color-text-secondary)]">Level:</label>
                        <select
                            value={logLevel || ''}
                            onChange={(e) => onLogLevelChange(e.target.value)}
                            className="text-sm"
                        >
                            <option value="">All Levels</option>
                            <option value="debug">Debug</option>
                            <option value="info">Info</option>
                            <option value="warning">Warning</option>
                            <option value="error">Error</option>
                            <option value="critical">Critical</option>
                        </select>
                    </div>
                )}

                {/* Clear Button */}
                <button
                    onClick={clearFilters}
                    className="text-sm text-[var(--color-text-secondary)] hover:text-black underline"
                >
                    Clear filters
                </button>
            </div>
        </div>
    );
}
