/**
 * History Page
 * History of processed images and logs with filtering.
 */

import { useState } from 'react';
import FilterBar from '../components/FilterBar';
import ImageGrid from '../components/ImageGrid';
import LogTable from '../components/LogTable';

export default function History() {
    const [activeTab, setActiveTab] = useState('images');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [logType, setLogType] = useState('');
    const [logLevel, setLogLevel] = useState('');

    return (
        <div className="space-y-6">
            {/* Page Header */}
            <div>
                <h1 className="text-2xl font-bold">History</h1>
                <p className="text-[var(--color-text-secondary)] mt-1">
                    Browse and filter processed images and system logs
                </p>
            </div>

            {/* Tab Navigation */}
            <div className="flex gap-1 border-b border-[var(--color-border)]">
                <button
                    onClick={() => setActiveTab('images')}
                    className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${activeTab === 'images'
                            ? 'border-black text-black'
                            : 'border-transparent text-[var(--color-text-secondary)] hover:text-black'
                        }`}
                >
                    Images
                </button>
                <button
                    onClick={() => setActiveTab('logs')}
                    className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors ${activeTab === 'logs'
                            ? 'border-black text-black'
                            : 'border-transparent text-[var(--color-text-secondary)] hover:text-black'
                        }`}
                >
                    Logs
                </button>
            </div>

            {/* Filter Bar */}
            <FilterBar
                startDate={startDate}
                endDate={endDate}
                logType={logType}
                logLevel={logLevel}
                onStartDateChange={setStartDate}
                onEndDateChange={setEndDate}
                onLogTypeChange={setLogType}
                onLogLevelChange={setLogLevel}
                showLogFilters={activeTab === 'logs'}
            />

            {/* Content */}
            {activeTab === 'images' ? (
                <ImageGrid startDate={startDate} endDate={endDate} />
            ) : (
                <LogTable
                    startDate={startDate}
                    endDate={endDate}
                    logType={logType}
                    logLevel={logLevel}
                />
            )}
        </div>
    );
}
