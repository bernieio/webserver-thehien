/**
 * Dashboard Page
 * Main dashboard with queue status, last image, and real-time logs.
 */

import StatusCard from '../components/StatusCard';
import ImagePreview from '../components/ImagePreview';
import LogPanel from '../components/LogPanel';

export default function Dashboard() {
    return (
        <div className="space-y-6">
            {/* Page Header */}
            <div>
                <h1 className="text-2xl font-bold">Dashboard</h1>
                <p className="text-[var(--color-text-secondary)] mt-1">
                    Real-time monitoring of the image processing system
                </p>
            </div>

            {/* Status Cards */}
            <StatusCard />

            {/* Image Preview */}
            <ImagePreview />

            {/* Log Panels */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <LogPanel type="activity" title="Activity Logs" maxHeight="350px" />
                <LogPanel type="server" title="Server Logs" maxHeight="350px" />
            </div>
        </div>
    );
}
