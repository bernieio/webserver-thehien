/**
 * System Page
 * System configuration and maintenance (placeholder).
 */

import { useStatus } from '../hooks/useStatus';
import { useCleanupLogs, useClearHotLogs } from '../hooks/useLogs';
import { formatDateTime } from '../utils/formatters';

export default function System() {
    const { data: status } = useStatus();
    const cleanupMutation = useCleanupLogs();
    const clearHotMutation = useClearHotLogs();

    const handleCleanup = async () => {
        if (window.confirm('Delete logs older than 90 days?')) {
            await cleanupMutation.mutateAsync(90);
            alert(`Cleaned up ${cleanupMutation.data?.deleted_count ?? 0} old logs`);
        }
    };

    const handleClearHot = async (type) => {
        if (window.confirm(`Clear ${type || 'all'} hot logs?`)) {
            await clearHotMutation.mutateAsync(type);
        }
    };

    return (
        <div className="space-y-6">
            {/* Page Header */}
            <div>
                <h1 className="text-2xl font-bold">System</h1>
                <p className="text-[var(--color-text-secondary)] mt-1">
                    System configuration and maintenance tools
                </p>
            </div>

            {/* System Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Server Info */}
                <div className="card">
                    <h2 className="text-lg font-semibold mb-4">Server Information</h2>
                    <div className="space-y-3 text-sm">
                        <div className="flex justify-between py-2 border-b border-[var(--color-border-light)]">
                            <span className="text-[var(--color-text-secondary)]">Status</span>
                            <span className="font-medium flex items-center gap-2">
                                <span className="status-dot success" />
                                {status?.status ?? 'Unknown'}
                            </span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-[var(--color-border-light)]">
                            <span className="text-[var(--color-text-secondary)]">Uptime</span>
                            <span className="font-medium">
                                {Math.floor((status?.uptime_seconds ?? 0) / 60)} minutes
                            </span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-[var(--color-border-light)]">
                            <span className="text-[var(--color-text-secondary)]">Memory Usage</span>
                            <span className="font-medium">{status?.system?.memory_mb ?? 0} MB</span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-[var(--color-border-light)]">
                            <span className="text-[var(--color-text-secondary)]">CPU Usage</span>
                            <span className="font-medium">{status?.system?.cpu_percent ?? 0}%</span>
                        </div>
                        <div className="flex justify-between py-2">
                            <span className="text-[var(--color-text-secondary)]">Threads</span>
                            <span className="font-medium">{status?.system?.threads ?? 0}</span>
                        </div>
                    </div>
                </div>

                {/* Queue Info */}
                <div className="card">
                    <h2 className="text-lg font-semibold mb-4">Queue Configuration</h2>
                    <div className="space-y-3 text-sm">
                        <div className="flex justify-between py-2 border-b border-[var(--color-border-light)]">
                            <span className="text-[var(--color-text-secondary)]">Max Size</span>
                            <span className="font-medium">{status?.queue?.max_size ?? 100}</span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-[var(--color-border-light)]">
                            <span className="text-[var(--color-text-secondary)]">Current Size</span>
                            <span className="font-medium">{status?.queue?.current_size ?? 0}</span>
                        </div>
                        <div className="flex justify-between py-2 border-b border-[var(--color-border-light)]">
                            <span className="text-[var(--color-text-secondary)]">Total Pushed</span>
                            <span className="font-medium">{status?.queue?.total_pushed ?? 0}</span>
                        </div>
                        <div className="flex justify-between py-2">
                            <span className="text-[var(--color-text-secondary)]">Total Popped</span>
                            <span className="font-medium">{status?.queue?.total_popped ?? 0}</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Maintenance Actions */}
            <div className="card">
                <h2 className="text-lg font-semibold mb-4">Maintenance</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-[var(--color-bg-secondary)] rounded-lg">
                        <h3 className="font-medium mb-2">Clean Old Logs</h3>
                        <p className="text-sm text-[var(--color-text-secondary)] mb-3">
                            Delete logs older than 90 days from the database.
                        </p>
                        <button
                            onClick={handleCleanup}
                            disabled={cleanupMutation.isPending}
                            className="btn btn-secondary w-full"
                        >
                            {cleanupMutation.isPending ? 'Cleaning...' : 'Clean Logs'}
                        </button>
                    </div>

                    <div className="p-4 bg-[var(--color-bg-secondary)] rounded-lg">
                        <h3 className="font-medium mb-2">Clear Activity Logs</h3>
                        <p className="text-sm text-[var(--color-text-secondary)] mb-3">
                            Clear the real-time activity log buffer.
                        </p>
                        <button
                            onClick={() => handleClearHot('activity')}
                            disabled={clearHotMutation.isPending}
                            className="btn btn-secondary w-full"
                        >
                            Clear Activity
                        </button>
                    </div>

                    <div className="p-4 bg-[var(--color-bg-secondary)] rounded-lg">
                        <h3 className="font-medium mb-2">Clear Server Logs</h3>
                        <p className="text-sm text-[var(--color-text-secondary)] mb-3">
                            Clear the real-time server log buffer.
                        </p>
                        <button
                            onClick={() => handleClearHot('server')}
                            disabled={clearHotMutation.isPending}
                            className="btn btn-secondary w-full"
                        >
                            Clear Server
                        </button>
                    </div>
                </div>
            </div>

            {/* Environment Info */}
            <div className="card">
                <h2 className="text-lg font-semibold mb-4">Environment</h2>
                <div className="bg-[var(--color-bg-secondary)] rounded-lg p-4 font-mono text-sm">
                    <div className="text-[var(--color-text-muted)]">API Endpoint</div>
                    <div className="mb-3">http://127.0.0.1:8000</div>

                    <div className="text-[var(--color-text-muted)]">Storage</div>
                    <div className="mb-3">Cloudflare R2 / KV / D1</div>

                    <div className="text-[var(--color-text-muted)]">Last Updated</div>
                    <div>{formatDateTime(status?.timestamp)}</div>
                </div>
            </div>
        </div>
    );
}
