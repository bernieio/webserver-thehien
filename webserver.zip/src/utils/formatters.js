/**
 * Date and formatting utilities
 */

/**
 * Format a date as a relative time string (e.g., "2 hours ago")
 */
export function formatRelativeTime(dateString) {
    if (!dateString) return 'Never';

    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffSecs < 60) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;

    return date.toLocaleDateString();
}

/**
 * Format a date as ISO date string (YYYY-MM-DD)
 */
export function formatDate(dateString) {
    if (!dateString) return '';
    return new Date(dateString).toISOString().split('T')[0];
}

/**
 * Format a date as full datetime string
 */
export function formatDateTime(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleString();
}

/**
 * Format a timestamp for logs (HH:MM:SS.mmm)
 */
export function formatLogTime(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toTimeString().slice(0, 12);
}

/**
 * Format file size in human-readable format
 */
export function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    if (!bytes) return '';

    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

/**
 * Format dimensions string
 */
export function formatDimensions(width, height) {
    if (!width || !height) return '';
    return `${width}×${height}`;
}

/**
 * Get today's date as ISO string
 */
export function getToday() {
    return new Date().toISOString().split('T')[0];
}

/**
 * Get date N days ago as ISO string
 */
export function getDaysAgo(days) {
    const date = new Date();
    date.setDate(date.getDate() - days);
    return date.toISOString().split('T')[0];
}
