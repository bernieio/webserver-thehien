/**
 * Custom hooks for images API using TanStack Query
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { imagesApi } from '../lib/api';

/**
 * Hook for listing images with filters
 */
export function useImages(params = {}, options = {}) {
    return useQuery({
        queryKey: ['images', params],
        queryFn: async () => {
            const { data } = await imagesApi.listImages(params);
            return data;
        },
        staleTime: 30000,
        ...options,
    });
}

/**
 * Hook for getting a single image
 */
export function useImage(id, options = {}) {
    return useQuery({
        queryKey: ['image', id],
        queryFn: async () => {
            const { data } = await imagesApi.getImage(id);
            return data;
        },
        enabled: !!id,
        ...options,
    });
}

/**
 * Hook for popping image from queue
 */
export function usePopFromQueue() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async () => {
            const { data } = await imagesApi.popFromQueue();
            return data;
        },
        onSuccess: (data) => {
            // Invalidate related queries
            queryClient.invalidateQueries({ queryKey: ['status'] });
            queryClient.invalidateQueries({ queryKey: ['queue-status'] });
            queryClient.invalidateQueries({ queryKey: ['images'] });
            queryClient.invalidateQueries({ queryKey: ['logs'] });
        },
    });
}

/**
 * Hook for deleting an image
 */
export function useDeleteImage() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (id) => {
            const { data } = await imagesApi.deleteImage(id);
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['images'] });
            queryClient.invalidateQueries({ queryKey: ['logs'] });
        },
    });
}
