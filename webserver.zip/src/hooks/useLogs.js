/**
 * Custom hooks for logs API using TanStack Query
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { logsApi } from '../lib/api';

/**
 * Hook for fetching latest logs (from KV hot storage)
 */
export function useLatestLogs(options = {}) {
    return useQuery({
        queryKey: ['logs', 'latest'],
        queryFn: async () => {
            const { data } = await logsApi.getLatestLogs();
            return data;
        },
        refetchInterval: options.refetchInterval ?? 2000,
        staleTime: 1000,
        ...options,
    });
}

/**
 * Hook for fetching activity logs only
 */
export function useActivityLogs(options = {}) {
    return useQuery({
        queryKey: ['logs', 'activity'],
        queryFn: async () => {
            const { data } = await logsApi.getActivityLogs();
            return data;
        },
        refetchInterval: options.refetchInterval ?? 2000,
        staleTime: 1000,
        ...options,
    });
}

/**
 * Hook for fetching server logs only
 */
export function useServerLogs(options = {}) {
    return useQuery({
        queryKey: ['logs', 'server'],
        queryFn: async () => {
            const { data } = await logsApi.getServerLogs();
            return data;
        },
        refetchInterval: options.refetchInterval ?? 2000,
        staleTime: 1000,
        ...options,
    });
}

/**
 * Hook for listing logs from D1 with filters
 */
export function useLogs(params = {}, options = {}) {
    return useQuery({
        queryKey: ['logs', 'history', params],
        queryFn: async () => {
            const { data } = await logsApi.listLogs(params);
            return data;
        },
        staleTime: 30000,
        ...options,
    });
}

/**
 * Hook for cleaning up old logs
 */
export function useCleanupLogs() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (days = 90) => {
            const { data } = await logsApi.cleanupLogs(days);
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['logs'] });
        },
    });
}

/**
 * Hook for clearing hot logs
 */
export function useClearHotLogs() {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: async (logType) => {
            const { data } = await logsApi.clearHotLogs(logType);
            return data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['logs', 'latest'] });
            queryClient.invalidateQueries({ queryKey: ['logs', 'activity'] });
            queryClient.invalidateQueries({ queryKey: ['logs', 'server'] });
        },
    });
}
