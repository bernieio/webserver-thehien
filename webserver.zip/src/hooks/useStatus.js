/**
 * Custom hooks for API data fetching using TanStack Query
 */

import { useQuery } from '@tanstack/react-query';
import { statusApi } from '../lib/api';

/**
 * Hook for fetching server status with polling
 */
export function useStatus(options = {}) {
    return useQuery({
        queryKey: ['status'],
        queryFn: async () => {
            const { data } = await statusApi.getStatus();
            return data;
        },
        refetchInterval: options.refetchInterval ?? 2000,
        staleTime: 1000,
        ...options,
    });
}

/**
 * Hook for fetching queue status only
 */
export function useQueueStatus(options = {}) {
    return useQuery({
        queryKey: ['queue-status'],
        queryFn: async () => {
            const { data } = await statusApi.getQueueStatus();
            return data;
        },
        refetchInterval: options.refetchInterval ?? 2000,
        staleTime: 1000,
        ...options,
    });
}

/**
 * Hook for health check
 */
export function useHealthCheck(options = {}) {
    return useQuery({
        queryKey: ['health'],
        queryFn: async () => {
            const { data } = await statusApi.getHealth();
            return data;
        },
        refetchInterval: options.refetchInterval ?? 5000,
        retry: 1,
        ...options,
    });
}
